# VideoHub + Global Jobs — Security Hardening Report

## Changes applied in this package

- Google sign-in now accepts only a Google ID token and verifies it server-side against the configured Google OAuth client ID. Issuer, audience, expiry, verified email, subject, and email are checked. Browser-supplied identity/profile fields are not used.
- Administrator provisioning uses an exact `ADMIN_EMAILS` allowlist; substring-based automatic administrator promotion is not used.
- Production startup requires `MONGODB_URI` and a 32+ character `AUTH_SECRET`. The application no longer uses a predictable production signing-secret fallback.
- Production API requests fail closed with HTTP 503 when the persistent database is unavailable or synchronization fails, instead of silently operating on ephemeral in-memory data.
- Password registration requires at least 12 characters. Passwordless seeded demo accounts cannot use the password login endpoint.
- Sessions are limited to 12 hours and use HttpOnly, Secure-in-production, SameSite=Strict cookies.
- Cookie-authenticated write requests in production must have an Origin matching the configured deployment origin (`APP_URL`, `URL`, `DEPLOY_PRIME_URL`, or `SITE_URL`).
- Added response security headers, reduced JSON/form body limits to 2 MB, and endpoint throttling for authentication and uploads.
- Raw video upload checks authentication before parsing the large upload body. Upload endpoints are throttled. Serverless video uploads are rejected unless durable Cloudinary storage is configured; `/tmp` is not treated as permanent storage.
- Updated `.env.example` and deployment documentation with production setup requirements.

## Local checks performed

- `node --check` passed for `index.js`, `admin.js`, `db.js`, `seed-data.js`, and `netlify/functions/api.js`.
- ZIP archive integrity check passed.

## Not yet verified

- `npm test` and `npm run build` were not run because project dependencies were not installed in this environment.
- Live Netlify HTTP checks could not be completed because the test environment could not resolve the deployment hostname.
- Google OAuth, MongoDB connectivity, Cloudinary uploads, and production Origin behavior still require validation using your real hosting environment variables.
- The in-process rate limiter is per serverless instance. Configure Netlify/Vercel edge/WAF rate limiting for global enforcement.

## Required production environment variables

- `NODE_ENV=production`
- `MONGODB_URI` and `MONGODB_DB_NAME`
- `AUTH_SECRET` generated uniquely, e.g. `openssl rand -hex 48`
- `APP_URL` set to the exact public HTTPS origin
- `ADMIN_EMAILS` containing only exact administrator email addresses
- `GOOGLE_CLIENT_ID` if Google sign-in is enabled
- `CLOUDINARY_CLOUD_NAME`, `CLOUDINARY_API_KEY`, and `CLOUDINARY_API_SECRET` for serverless video uploads

Do not deploy until these variables are set in your hosting provider's secret/environment settings. Rotate any credentials previously exposed in source files, chat, or archives.
