# VideoHub + Global Jobs 🎥🌍

A colorful, modern, claymorphism-based full-stack web platform combining **short-video feeds (TikTok/Shorts style)**, **long-form video streaming (YouTube style)**, **creator channel subscriptions**, **real-time style notification center**, and a specialized **global job-search portal** focused on Aluminium, Curtain Wall & Façade Engineering, Architectural BIM, AutoCAD, and construction megaprojects.

Target Deployment: **Netlify / Node.js 24.x**  
Database: **MongoDB Atlas** (all data is persisted when MONGODB_URI is set; otherwise in-memory preview mode). Video storage: **Cloudinary** when configured.  
Styling: **Tailwind CSS v4 & Claymorphism soft 3D design system**  

---

## 🌟 Key Features

1. **Shorts Video Experience**:
   - Vertical fullscreen-style player with quick swipe/button controls.
   - Like animations with particle confetti, interactive comment drawer, follow creator, share link, mute/unmute, and content reporting.

2. **Long-Form Video Player**:
   - Custom controls: play/pause, seek scrubber, volume slider, playback speed options (0.5x, 1x, 1.25x, 1.5x, 2x), fullscreen.
   - Channel cards with subscriber counts and follow toggles.
   - Interactive comment posting, likes count, description box, and related engineering recommendations rail.

3. **Global Job-Search Portal**:
   - Specialized categories:
     - Aluminium & Façade Engineering
     - Curtain Wall & Glazing
     - Revit & BIM
     - Architectural Engineering
     - Civil Engineering
     - AutoCAD Drafting
     - Construction Management
     - Software & IT
   - Search by keyword, title, country, city, employment type (Full-time, Remote, Hybrid), and salary range.
   - **Easy Apply Modal**: Attach candidate CV/resume (PDF/DOCX validation), portfolio link, and cover note.
   - **Candidate Tracker**: Live application statuses (*Submitted, Under Review, Shortlisted, Interview, Hired, Rejected*).
   - **Employer Vacancy Publisher**: Post vacancies with salary ranges and qualifications.

4. **Creator Memberships & Subscriptions**:
   - Configurable tiers:
     - **Free Explorer** ($0)
     - **Creator Plus** ($4.99/mo)
     - **Pro Creator** ($9.99/mo)
     - **Business Recruiter** ($19.99/mo)
   - Interactive 1-click upgrade simulation with confetti and notification confirmation.

5. **Notification Center**:
   - Bell icon with live badge counter.
   - Categorized alerts for video likes, comments, job application status updates, mentions, and administrative broadcasts.

6. **Direct Messaging**:
   - Recruiter-to-candidate and creator communication chat threads with live timestamps.

7. **Server-Side Administrative Engine (`server/admin.js`)**:
   - Protected API routes authorized on server.
   - Platform KPIs (Total users, active vacancies, applications, subscriptions, reports).
   - User account management (suspend, restore, promote roles, toggle verified checkmark).
   - Video content moderation (approve, flag, remove).
   - Job vacancy moderation (feature boost, close, reactivate).
   - Community reports resolution queue.
   - Platform announcement broadcast tool.
   - Immutable audit logs.

---

## 🧪 Sample Profiles (Development Only)

The bundled seed dataset contains sample profiles for local development and preview only. Do not expose role-switching or passwordless demo access in a production deployment:
- **Tariq Mansoor** (Candidate & Façade Engineer) — Test job search, CV Easy Apply, and video comments.
- **Façade Engineering Academy** (Top Creator) — Test channel dashboard, subscriber growth, and video publishing.
- **Apex Façade Systems** (Employer & Recruiter) — Test posting vacancies, reviewing candidate CVs, updating status, and applicant messaging.
- **Alex Sterling** (Platform Administrator) — Test full governance in the Admin Dashboard via `server/admin.js`.

---

## 🗄️ Connecting Your MongoDB Atlas Database

1. Create a free cluster on [MongoDB Atlas](https://www.mongodb.com/cloud/atlas).
2. Under **Database Access**, create a database user and password.
3. Under **Network Access**, restrict access to your hosting provider’s outbound IP addresses where practical. If broad access is unavoidable for serverless hosting, use a dedicated least-privilege database user and a strong unique password.
4. Copy your connection string:
   ```env
   MONGODB_URI="mongodb+srv://<username>:<password>@cluster0.mongodb.net/?retryWrites=true&w=majority"
   MONGODB_DB_NAME="videohub_jobs"
   ```
5. Paste `MONGODB_URI` into your Vercel project environment variables or local `.env` file.
6. In production, the API fails closed with HTTP 503 if MongoDB is unavailable; it will not silently serve writes from temporary in-memory storage. In-memory seed data is for local development only.

---

## 🔐 Production Security Checklist

Before enabling production traffic:

1. Set `NODE_ENV=production`, `MONGODB_URI`, `MONGODB_DB_NAME`, and a unique `AUTH_SECRET` generated with `openssl rand -hex 48`. Never reuse a development secret.
2. Set `APP_URL` to the exact HTTPS origin users visit. Cookie-authenticated write requests from other origins are rejected.
3. Set `ADMIN_EMAILS` to exact, controlled email addresses only. Google sign-in accepts a server-verified Google ID token; browser-supplied name/email/avatar fields are not trusted.
4. Do not enable demo accounts or demo role switching in production. Passwordless seeded demo users cannot sign in through the password login endpoint.
5. Configure Cloudinary (or another durable object store) for production video uploads. Local `/tmp` uploads on serverless hosts are temporary and must not be treated as permanent storage.
6. Configure host-level/WAF rate limits for authentication and upload endpoints. The in-process limiter is only a per-instance secondary control and is not a global serverless rate limiter.
7. Restrict MongoDB network access and database-user privileges. Back up the database and test restore procedures.
8. Rotate any credentials that were ever committed, pasted into source files, or shared in archives. Store production secrets only in the hosting provider's encrypted environment-variable settings.

The API uses 12-hour signed sessions, HttpOnly/Secure/SameSite=Strict cookies, request-origin checks for cookie-authenticated mutations, security response headers, smaller JSON request limits, and endpoint throttling. These controls reduce risk but do not replace a professional security review or host-level protections.

---

## ☁️ Deploying to Vercel

This project uses a root-level Express entry point (`index.js`) with a default-exported Express app. Vercel detects that entry point and deploys it as the serverless backend. The Vite frontend is built into `dist/`; the `postbuild` script copies those generated assets into `public/` so Vercel can serve them as static files. Existing `public/videos/` media is preserved.

1. Import the repository into Vercel. Set the **Root Directory** to the folder containing `package.json` and `index.js`.
2. Use **Node.js 24.x**. The `engines.node` field is set to `24.x`.
3. Set **Build Command** to `npm run build`.
4. Leave **Output Directory** empty for the Express deployment. Do not set it to `dist`.
5. Add the production environment variables listed in `SECURITY.md` and `.env.example` in Vercel Project Settings. At minimum, production requires `NODE_ENV=production`, `MONGODB_URI`, `MONGODB_DB_NAME`, a unique `AUTH_SECRET` of at least 32 characters, and `APP_URL` set to the exact deployed HTTPS origin. Add `ADMIN_EMAILS` and provider credentials only when those features are configured.
6. Deploy, then verify `/api/health`, sign-in, a protected write, and a browser route directly (not only through the home page).

Do not upload a real `.env` file or commit production secrets. Configure Cloudinary for durable video uploads; serverless local disk is not persistent. Payments remain disabled in production until a real payment processor and verified webhook ledger are implemented.

## ☁️ Deploying to Netlify

1. Import the repository into Netlify.
2. Use **Node.js 24.x** and the included `netlify.toml` settings.
3. Build command: `npm run build`; publish directory: `dist`.
4. Add the production environment variables listed in `SECURITY.md` and `.env.example`.
5. Verify `/api/health` and the key application workflows after deployment.

## 🧪 Automated Testing & Verification

Run the test suite:
```bash
npm test
```
Run type-checking:
```bash
npm run lint
```
Compile production build:
```bash
npm run build
```
Start development full-stack server:
```bash
npm run dev
```


## Security hardening
Review [SECURITY.md](./SECURITY.md) before deploying. Run `npm run security:check` for static security smoke checks. Production requires Node.js 24, MongoDB, a strong `AUTH_SECRET`, HTTPS, and a configured administrator allowlist. Demo payment and payout flows are intentionally disabled in production until a real payment provider and verified webhooks are integrated.
