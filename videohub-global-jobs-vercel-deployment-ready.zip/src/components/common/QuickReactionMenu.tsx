import React, { useState, useEffect } from 'react';

const REACTIONS = [
  { id: 'heart', emoji: '❤️' },
  { id: 'fire', emoji: '🔥' },
  { id: 'wow', emoji: '😮' },
  { id: 'clap', emoji: '👏' }
];

interface QuickReactionMenuProps {
  videoId: string;
}

export const QuickReactionMenu: React.FC<QuickReactionMenuProps> = ({ videoId }) => {
  const [counts, setCounts] = useState<Record<string, number>>({});
  const [isOpen, setIsOpen] = useState(false);

  useEffect(() => {
    const saved = localStorage.getItem(`reactions-${videoId}`);
    if (saved) {
      setCounts(JSON.parse(saved));
    }
  }, [videoId]);

  const handleReaction = (reactionId: string) => {
    const newCounts = { ...counts, [reactionId]: (counts[reactionId] || 0) + 1 };
    setCounts(newCounts);
    localStorage.setItem(`reactions-${videoId}`, JSON.stringify(newCounts));
    setIsOpen(false);
  };

  const totalReactions = Object.values(counts).reduce((acc, count) => acc + count, 0);

  return (
    <div className="absolute top-2 left-2 z-10">
      <button
        onClick={(e) => {
          e.stopPropagation();
          setIsOpen(!isOpen);
        }}
        className="flex items-center gap-1.5 px-2 py-1 rounded-xl bg-black/60 text-white text-[10px] font-bold backdrop-blur-sm hover:bg-black/80 transition"
      >
        <span>{totalReactions > 0 ? totalReactions : '❤️'}</span>
      </button>

      {isOpen && (
        <div 
          className="absolute top-full left-0 mt-1 flex gap-1 p-1.5 rounded-2xl bg-white dark:bg-slate-800 shadow-xl border border-slate-200 dark:border-slate-700"
          onClick={(e) => e.stopPropagation()}
        >
          {REACTIONS.map((r) => (
            <button
              key={r.id}
              onClick={() => handleReaction(r.id)}
              className="text-lg hover:scale-125 transition-transform"
            >
              {r.emoji}
            </button>
          ))}
        </div>
      )}
    </div>
  );
};
