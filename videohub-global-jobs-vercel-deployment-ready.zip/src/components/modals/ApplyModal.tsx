import React, { useState } from 'react';
import { useApp } from '../../context/AppContext.tsx';
import { X, Briefcase, FileText, CheckCircle2, UploadCloud, Link as LinkIcon, Building2, Video as VideoIcon, Play, Sparkles } from 'lucide-react';
import confetti from 'canvas-confetti';

const SAMPLE_PITCH_OPTIONS = [
  {
    title: 'Façade Inspection & Mockup Dynamic Testing Breakdown',
    url: '/api/media/stream/video1.mp4',
    duration: '0:45'
  },
  {
    title: 'Aluminium Extrusion Dies & Structural Calculations Walkthrough',
    url: '/api/media/stream/video2.mp4',
    duration: '1:10'
  },
  {
    title: 'Revit BIM Parametric Mullions & Shop Drawings Showcase',
    url: '/api/media/stream/video3.mp4',
    duration: '0:58'
  }
];

export const ApplyModal: React.FC = () => {
  const { applyModalJob, setApplyModalJob, currentUser, showToast, setActiveView } = useApp();
  const [formData, setFormData] = useState({
    name: currentUser?.name || '',
    email: currentUser?.email || '',
    phone: currentUser?.phone || '+966 55 123 4567',
    resumeFileName: `${(currentUser?.name || 'Candidate').replace(/\s+/g, '_')}_CV.pdf`,
    portfolioUrl: 'https://behance.net/portfolio-sample',
    coverNote: `I am highly interested in the ${applyModalJob?.title} position at ${applyModalJob?.company}. My background aligns well with the stated requirements.`,
    includeVideoPitch: true,
    videoPitchTitle: 'Façade Inspection & Mockup Dynamic Testing Breakdown',
    videoPitchUrl: '/api/media/stream/video1.mp4',
    videoPitchDuration: '0:45'
  });
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  if (!applyModalJob) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);

    try {
      const res = await fetch(`/api/jobs/${applyModalJob.id}/apply`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          applicantName: formData.name,
          applicantEmail: formData.email,
          applicantPhone: formData.phone,
          resumeFileName: formData.resumeFileName,
          portfolioUrl: formData.portfolioUrl,
          coverNote: formData.coverNote,
          videoPitchUrl: formData.includeVideoPitch ? formData.videoPitchUrl : undefined,
          videoPitchTitle: formData.includeVideoPitch ? formData.videoPitchTitle : undefined,
          videoPitchDuration: formData.includeVideoPitch ? formData.videoPitchDuration : undefined
        })
      });

      if (!res.ok) {
        const data = await res.json();
        throw new Error(data.error || 'Application failed');
      }

      setSubmitted(true);
      confetti({
        particleCount: 80,
        spread: 60,
        origin: { y: 0.6 }
      });
      showToast('Application successfully submitted!');
    } catch (err: any) {
      showToast(err.message, 'error');
    } finally {
      setSubmitting(false);
    }
  };

  const handleClose = () => {
    setApplyModalJob(null);
    setSubmitted(false);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg clay-card p-6 bg-white dark:bg-[#181D2E] text-slate-800 dark:text-slate-100 shadow-2xl max-h-[90vh] overflow-y-auto no-scrollbar">
        <button
          onClick={handleClose}
          className="absolute top-4 right-4 p-2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-xl"
        >
          <X className="w-5 h-5" />
        </button>

        {submitted ? (
          <div className="text-center py-8">
            <div className="w-16 h-16 mx-auto rounded-3xl bg-emerald-100 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 flex items-center justify-center shadow-lg shadow-emerald-500/20 mb-4 animate-bounce">
              <CheckCircle2 className="w-8 h-8" />
            </div>
            <h3 className="text-xl font-extrabold text-slate-900 dark:text-slate-100 mb-1">
              Application Submitted!
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 max-w-md mx-auto mb-6">
              Your candidate profile and resume have been sent to <strong>{applyModalJob.company}</strong> for the <strong>{applyModalJob.title}</strong> opening.
            </p>
            <div className="flex items-center justify-center gap-3">
              <button
                onClick={() => {
                  handleClose();
                  setActiveView('applications');
                }}
                className="clay-btn clay-btn-mint px-4 py-2 text-xs font-bold"
              >
                Track in My Applications
              </button>
              <button
                onClick={handleClose}
                className="clay-btn clay-btn-secondary px-4 py-2 text-xs font-bold"
              >
                Close
              </button>
            </div>
          </div>
        ) : (
          <div>
            <div className="flex items-center gap-3 mb-5">
              <img
                src={applyModalJob.companyLogo}
                alt={applyModalJob.company}
                className="w-12 h-12 rounded-2xl object-cover border border-slate-200 dark:border-slate-700 shadow-sm"
              />
              <div>
                <h3 className="text-base font-extrabold text-slate-900 dark:text-slate-100 leading-tight">
                  {applyModalJob.title}
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400 flex items-center gap-1.5 mt-0.5">
                  <Building2 className="w-3.5 h-3.5" />
                  {applyModalJob.company} • {applyModalJob.location}
                </p>
              </div>
            </div>

            <form onSubmit={handleSubmit} className="space-y-3.5">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-600 dark:text-slate-300 mb-1">Full Name</label>
                  <input
                    type="text"
                    required
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    className="w-full px-3 py-2 text-xs clay-input"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-600 dark:text-slate-300 mb-1">Email</label>
                  <input
                    type="email"
                    required
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    className="w-full px-3 py-2 text-xs clay-input"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-600 dark:text-slate-300 mb-1">Phone Number</label>
                  <input
                    type="tel"
                    required
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    className="w-full px-3 py-2 text-xs clay-input"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-600 dark:text-slate-300 mb-1">Portfolio or LinkedIn</label>
                  <input
                    type="url"
                    value={formData.portfolioUrl}
                    onChange={(e) => setFormData({ ...formData, portfolioUrl: e.target.value })}
                    className="w-full px-3 py-2 text-xs clay-input"
                  />
                </div>
              </div>

              {/* CV Attachment Box */}
              <div>
                <label className="block text-xs font-bold text-slate-600 dark:text-slate-300 mb-1">Attach Resume / CV</label>
                <div className="p-3 rounded-2xl border-2 border-dashed border-violet-300 dark:border-violet-700 bg-violet-50/50 dark:bg-violet-950/20 flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <FileText className="w-6 h-6 text-violet-600 dark:text-violet-400" />
                    <div>
                      <p className="text-xs font-bold text-slate-800 dark:text-slate-200">{formData.resumeFileName}</p>
                      <p className="text-[10px] text-slate-400">PDF, DOCX up to 10MB • Verified File</p>
                    </div>
                  </div>
                  <label className="clay-btn clay-btn-secondary px-3 py-1 text-[11px] font-bold cursor-pointer">
                    Change
                    <input
                      type="file"
                      accept=".pdf,.doc,.docx"
                      className="hidden"
                      onChange={(e) => {
                        const file = e.target.files?.[0];
                        if (file) {
                          setFormData({ ...formData, resumeFileName: file.name });
                          showToast(`Selected file: ${file.name}`);
                        }
                      }}
                    />
                  </label>
                </div>
              </div>

              {/* Video Pitch / Reel Showcase Section */}
              <div className="p-3.5 rounded-2xl bg-gradient-to-r from-violet-500/10 via-pink-500/10 to-amber-500/10 border border-violet-300/40 dark:border-violet-700/40 space-y-2.5">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <VideoIcon className="w-4 h-4 text-pink-600 dark:text-pink-400" />
                    <span className="text-xs font-black text-slate-900 dark:text-white">
                      Video Pitch / Engineering Showcase Reel
                    </span>
                    <span className="px-2 py-0.5 rounded-full text-[9px] font-black bg-pink-500 text-white animate-pulse">
                      Recommended
                    </span>
                  </div>
                  <label className="flex items-center gap-1.5 cursor-pointer text-xs font-bold text-slate-700 dark:text-slate-300">
                    <input
                      type="checkbox"
                      checked={formData.includeVideoPitch}
                      onChange={(e) => setFormData({ ...formData, includeVideoPitch: e.target.checked })}
                      className="rounded text-violet-600 focus:ring-violet-500"
                    />
                    <span>Attach</span>
                  </label>
                </div>

                {formData.includeVideoPitch && (
                  <div className="space-y-2 pt-1 animate-in fade-in duration-200">
                    <p className="text-[11px] text-slate-500 dark:text-slate-400">
                      Stand out to recruiters with a 60-second video explaining your façade calculations, CAD drawings, or portfolio:
                    </p>

                    <div className="space-y-1.5">
                      {SAMPLE_PITCH_OPTIONS.map((opt) => {
                        const isSelected = formData.videoPitchUrl === opt.url;
                        return (
                          <button
                            key={opt.url}
                            type="button"
                            onClick={() =>
                              setFormData({
                                ...formData,
                                videoPitchTitle: opt.title,
                                videoPitchUrl: opt.url,
                                videoPitchDuration: opt.duration
                              })
                            }
                            className={`w-full text-left p-2.5 rounded-xl border transition flex items-center justify-between text-xs font-bold ${
                              isSelected
                                ? 'bg-violet-600 text-white border-violet-600 shadow-md'
                                : 'bg-white/80 dark:bg-slate-800 text-slate-700 dark:text-slate-200 border-slate-200 dark:border-slate-700 hover:bg-slate-50'
                            }`}
                          >
                            <div className="flex items-center gap-2 min-w-0 pr-2">
                              <Play className={`w-3.5 h-3.5 flex-shrink-0 ${isSelected ? 'fill-white' : 'text-violet-500'}`} />
                              <span className="truncate">{opt.title}</span>
                            </div>
                            <span className={`text-[10px] px-1.5 py-0.5 rounded ${isSelected ? 'bg-white/20' : 'bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-300'}`}>
                              {opt.duration}
                            </span>
                          </button>
                        );
                      })}
                    </div>
                  </div>
                )}
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-600 dark:text-slate-300 mb-1">Cover Note</label>
                <textarea
                  rows={3}
                  value={formData.coverNote}
                  onChange={(e) => setFormData({ ...formData, coverNote: e.target.value })}
                  className="w-full px-3 py-2 text-xs clay-input"
                  placeholder="Introduce yourself and highlight relevant experience..."
                />
              </div>

              <div className="pt-2 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={handleClose}
                  className="clay-btn clay-btn-secondary px-4 py-2 text-xs font-bold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={submitting}
                  className="clay-btn clay-btn-mint px-5 py-2 text-xs font-bold shadow-md active:scale-95 transition disabled:opacity-50"
                >
                  {submitting ? 'Submitting Application...' : 'Submit Application'}
                </button>
              </div>
            </form>
          </div>
        )}
      </div>
    </div>
  );
};
