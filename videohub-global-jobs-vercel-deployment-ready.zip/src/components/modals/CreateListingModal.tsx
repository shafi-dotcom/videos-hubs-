import React, { useState } from 'react';
import { useApp } from '../../context/AppContext.tsx';
import { StoreProduct, ProductCategory, ProductCondition } from '../../types/index.ts';
import {
  X,
  Plus,
  Trash2,
  Sparkles,
  DollarSign,
  Package,
  Truck,
  ShieldCheck,
  Check,
  Image as ImageIcon,
  Tag,
  Layers,
  FileCheck
} from 'lucide-react';
import confetti from 'canvas-confetti';

interface CreateListingModalProps {
  isOpen: boolean;
  onClose: () => void;
  onProductCreated: (product: StoreProduct) => void;
}

const PRESET_IMAGES = [
  {
    label: '4K Camera & Tech',
    url: 'https://images.unsplash.com/photo-1516035069371-29a1b244cc32?w=800&h=600&fit=crop'
  },
  {
    label: 'ANC Headphones',
    url: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=800&h=600&fit=crop'
  },
  {
    label: 'Titanium Smartwatch',
    url: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=800&h=600&fit=crop'
  },
  {
    label: 'Fashion & Techwear',
    url: 'https://images.unsplash.com/photo-1551028719-00167b16eac5?w=800&h=600&fit=crop'
  },
  {
    label: 'Espresso & Kitchen',
    url: 'https://images.unsplash.com/photo-1517668808822-9ebb02f2a0e6?w=800&h=600&fit=crop'
  },
  {
    label: 'Power Tools & DIY',
    url: 'https://images.unsplash.com/photo-1504148455328-c376907d081c?w=800&h=600&fit=crop'
  },
  {
    label: 'Fitness & Sports',
    url: 'https://images.unsplash.com/photo-1517838277536-f5f99be501cd?w=800&h=600&fit=crop'
  },
  {
    label: 'Digital Code / Templates',
    url: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=800&h=600&fit=crop'
  },
  {
    label: 'Creator Merch & Apparel',
    url: 'https://images.unsplash.com/photo-1556905055-8f358a7a47b2?w=800&h=600&fit=crop'
  },
  {
    label: 'Industrial & Hardware',
    url: 'https://images.unsplash.com/photo-1581092335397-9583fe92d232?w=800&h=600&fit=crop'
  }
];

export const CreateListingModal: React.FC<CreateListingModalProps> = ({
  isOpen,
  onClose,
  onProductCreated
}) => {
  const { currentUser, showToast, setAuthModalOpen } = useApp();

  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState<ProductCategory>('electronics');
  const [condition, setCondition] = useState<ProductCondition>('new');
  const [price, setPrice] = useState('');
  const [compareAtPrice, setCompareAtPrice] = useState('');
  const [stock, setStock] = useState('15');
  const [brand, setBrand] = useState(currentUser?.displayName || currentUser?.name || 'Dometech Engineering');
  const [selectedImageUrl, setSelectedImageUrl] = useState(PRESET_IMAGES[0].url);
  const [customImageUrl, setCustomImageUrl] = useState('');
  const [freeShipping, setFreeShipping] = useState(true);
  const [shippingTime, setShippingTime] = useState('2–4 Business Days (Express)');
  const [shipsFrom, setShipsFrom] = useState(currentUser?.country || 'Riyadh, Saudi Arabia');

  // Dynamic Bullet Features
  const [features, setFeatures] = useState<string[]>([
    'Heavy-duty architectural grade engineering standard',
    'Tested and certified for GCC environmental tolerances',
    'Backed by 12-month manufacturer warranty'
  ]);
  const [newFeatureText, setNewFeatureText] = useState('');

  // Dynamic Specifications key-value pairs
  const [specList, setSpecList] = useState<{ key: string; value: string }[]>([
    { key: 'Material', value: 'Architectural Aluminum 6063-T6' },
    { key: 'Standard', value: 'ASTM / EN 12020 Compliance' },
    { key: 'Application', value: 'Curtain Wall & Façade Installation' }
  ]);
  const [specKey, setSpecKey] = useState('');
  const [specVal, setSpecVal] = useState('');

  const [isSubmitting, setIsSubmitting] = useState(false);

  if (!isOpen) return null;

  const handleAddFeature = () => {
    if (!newFeatureText.trim()) return;
    setFeatures(prev => [...prev, newFeatureText.trim()]);
    setNewFeatureText('');
  };

  const handleRemoveFeature = (idx: number) => {
    setFeatures(prev => prev.filter((_, i) => i !== idx));
  };

  const handleAddSpec = () => {
    if (!specKey.trim() || !specVal.trim()) return;
    setSpecList(prev => [...prev, { key: specKey.trim(), value: specVal.trim() }]);
    setSpecKey('');
    setSpecVal('');
  };

  const handleRemoveSpec = (idx: number) => {
    setSpecList(prev => prev.filter((_, i) => i !== idx));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) {
      setAuthModalOpen(true);
      return;
    }

    if (!title.trim() || !price) {
      showToast('Please provide a product title and price', 'error');
      return;
    }

    const priceNum = parseFloat(price);
    if (isNaN(priceNum) || priceNum <= 0) {
      showToast('Please enter a valid price', 'error');
      return;
    }

    const finalImage = customImageUrl.trim() || selectedImageUrl;

    const specsObj: Record<string, string> = {};
    specList.forEach(s => {
      if (s.key.trim() && s.value.trim()) {
        specsObj[s.key.trim()] = s.value.trim();
      }
    });

    const categoryNames: Record<ProductCategory, string> = {
      all: 'All Products',
      electronics: 'Electronics & Tech Gadgets',
      fashion: 'Fashion & Apparel',
      home_living: 'Home, Kitchen & Living',
      tools_diy: 'Tools, Hardware & DIY',
      sports_fitness: 'Sports, Fitness & Outdoor',
      digital_assets: 'Digital Assets, Software & Templates',
      creator_merch: 'Creator Merch & Swag',
      industrial_facade: 'Industrial, Architectural & Façade',
      facade_hardware: 'Façade Hardware & Glass Lifters',
      fabrication_tools: 'Fabrication & Site Tools',
      safety_gear: 'Safety Gear & Site PPE',
      machinery: 'Heavy Machinery & Fabrication Plant',
      bim_templates: 'BIM & Digital Engineering Assets'
    };

    const payload = {
      title: title.trim(),
      description: description.trim() || 'Professional grade product listed on VideoHub Store.',
      category,
      categoryName: categoryNames[category],
      price: priceNum,
      compareAtPrice: compareAtPrice ? parseFloat(compareAtPrice) : undefined,
      condition,
      stock: parseInt(stock) || 10,
      images: [finalImage],
      thumbnailUrl: finalImage,
      features,
      specifications: specsObj,
      brand: brand.trim(),
      shippingInfo: {
        freeShipping,
        estimatedDelivery: shippingTime,
        shipsFrom
      },
      tags: [category, condition, 'StoreProduct']
    };

    try {
      setIsSubmitting(true);
      const res = await fetch('/api/store/products', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      const data = await res.json();
      if (res.ok && data.product) {
        confetti({ particleCount: 70, spread: 60 });
        showToast('🎉 Product successfully listed in the store!', 'success');
        onProductCreated(data.product);
        onClose();
      } else {
        showToast(data.error || 'Failed to list product', 'error');
      }
    } catch (err: any) {
      showToast('Error listing product: ' + err.message, 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  const previewImage = customImageUrl.trim() || selectedImageUrl;
  const numPrice = parseFloat(price) || 0;
  const numCompare = parseFloat(compareAtPrice) || 0;

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
      <div className="clay-card bg-white dark:bg-[#131722] max-w-4xl w-full max-h-[92vh] overflow-y-auto no-scrollbar rounded-3xl p-5 sm:p-8 space-y-6 shadow-2xl border border-slate-200/80 dark:border-slate-800 animate-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-amber-500 to-orange-500 text-white flex items-center justify-center shadow-lg shadow-amber-500/25">
              <Package className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-black text-slate-900 dark:text-slate-100">
                List a Product in the Online Store
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Offer electronics, fashion, home essentials, tools, sports gear, digital software templates, or creator merch
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Left 2 Cols: Form Fields */}
            <div className="lg:col-span-2 space-y-5">
              {/* Product Basic Info */}
              <div className="space-y-3">
                <label className="text-xs font-black uppercase tracking-wider text-slate-400">
                  1. Product Details
                </label>

                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Product Title <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Dual-Cup Heavy Vacuum Glass Suction Lifter (150kg)"
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    className="w-full px-3.5 py-2.5 text-xs clay-input rounded-xl"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Description & Applications
                  </label>
                  <textarea
                    rows={3}
                    placeholder="Highlight technical advantages, load ratings, compatibility, and certifications..."
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    className="w-full px-3.5 py-2 text-xs clay-input rounded-xl"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                      Category
                    </label>
                    <select
                      value={category}
                      onChange={(e) => setCategory(e.target.value as ProductCategory)}
                      className="w-full px-3 py-2 text-xs clay-input bg-white dark:bg-slate-800 rounded-xl"
                    >
                      <option value="electronics">Electronics & Tech Gadgets</option>
                      <option value="fashion">Fashion & Apparel</option>
                      <option value="home_living">Home, Kitchen & Living</option>
                      <option value="tools_diy">Tools, Hardware & DIY</option>
                      <option value="sports_fitness">Sports, Fitness & Outdoor</option>
                      <option value="digital_assets">Digital Assets, Software & Templates</option>
                      <option value="creator_merch">Creator Merch & Swag</option>
                      <option value="industrial_facade">Industrial, Architectural & Façade</option>
                      <option value="fabrication_tools">Fabrication & Site Tools</option>
                      <option value="facade_hardware">Façade Hardware & Glass Lifters</option>
                      <option value="safety_gear">Safety Gear & Site PPE</option>
                      <option value="machinery">Heavy Machinery & Cutting Plant</option>
                      <option value="bim_templates">BIM & Engineering Assets</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                      Condition
                    </label>
                    <select
                      value={condition}
                      onChange={(e) => setCondition(e.target.value as ProductCondition)}
                      className="w-full px-3 py-2 text-xs clay-input bg-white dark:bg-slate-800 rounded-xl"
                    >
                      <option value="new">Brand New (Factory Sealed)</option>
                      <option value="engineering_spec">Certified Engineering Spec</option>
                      <option value="certified_refurbished">Certified Refurbished</option>
                      <option value="digital">Instant Digital Download</option>
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                      Selling Price (USD $) <span className="text-rose-500">*</span>
                    </label>
                    <div className="relative">
                      <span className="absolute left-3 top-2.5 text-xs text-slate-400 font-bold">$</span>
                      <input
                        type="number"
                        step="0.01"
                        min="1"
                        required
                        placeholder="89.00"
                        value={price}
                        onChange={(e) => setPrice(e.target.value)}
                        className="w-full pl-7 pr-3 py-2 text-xs clay-input font-bold rounded-xl"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                      Original Price (Optional)
                    </label>
                    <div className="relative">
                      <span className="absolute left-3 top-2.5 text-xs text-slate-400 font-bold">$</span>
                      <input
                        type="number"
                        step="0.01"
                        placeholder="120.00"
                        value={compareAtPrice}
                        onChange={(e) => setCompareAtPrice(e.target.value)}
                        className="w-full pl-7 pr-3 py-2 text-xs clay-input rounded-xl"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                      Stock Inventory
                    </label>
                    <input
                      type="number"
                      min="1"
                      placeholder="15"
                      value={stock}
                      onChange={(e) => setStock(e.target.value)}
                      className="w-full px-3 py-2 text-xs clay-input rounded-xl"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Brand / Manufacturer Name
                  </label>
                  <input
                    type="text"
                    value={brand}
                    onChange={(e) => setBrand(e.target.value)}
                    className="w-full px-3 py-2 text-xs clay-input rounded-xl"
                  />
                </div>
              </div>

              {/* Product Photos */}
              <div className="space-y-3 pt-4 border-t border-slate-100 dark:border-slate-800">
                <label className="text-xs font-black uppercase tracking-wider text-slate-400">
                  2. Product Images
                </label>

                <div>
                  <p className="text-xs font-bold text-slate-700 dark:text-slate-300 mb-2">
                    Select a Preset Image Gallery:
                  </p>
                  <div className="grid grid-cols-3 sm:grid-cols-6 gap-2">
                    {PRESET_IMAGES.map((preset) => (
                      <button
                        key={preset.url}
                        type="button"
                        onClick={() => {
                          setSelectedImageUrl(preset.url);
                          setCustomImageUrl('');
                        }}
                        className={`relative rounded-xl overflow-hidden aspect-square border-2 transition active:scale-95 group ${
                          selectedImageUrl === preset.url && !customImageUrl
                            ? 'border-amber-500 ring-2 ring-amber-400/50 shadow-md'
                            : 'border-slate-200 dark:border-slate-800 opacity-70 hover:opacity-100'
                        }`}
                      >
                        <img src={preset.url} alt={preset.label} className="w-full h-full object-cover" />
                        <div className="absolute inset-x-0 bottom-0 bg-black/60 text-white text-[9px] font-bold p-1 truncate">
                          {preset.label}
                        </div>
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Or Enter Custom Image URL:
                  </label>
                  <input
                    type="url"
                    placeholder="https://..."
                    value={customImageUrl}
                    onChange={(e) => setCustomImageUrl(e.target.value)}
                    className="w-full px-3 py-2 text-xs clay-input rounded-xl"
                  />
                </div>
              </div>

              {/* Key Features Generator */}
              <div className="space-y-3 pt-4 border-t border-slate-100 dark:border-slate-800">
                <label className="text-xs font-black uppercase tracking-wider text-slate-400">
                  3. Key Features & Highlights
                </label>

                <div className="space-y-1.5">
                  {features.map((feat, idx) => (
                    <div key={idx} className="flex items-center justify-between gap-2 p-2 rounded-xl bg-slate-50 dark:bg-slate-900/40 border border-slate-200/60 dark:border-slate-800 text-xs">
                      <div className="flex items-center gap-2">
                        <Check className="w-3.5 h-3.5 text-emerald-500 flex-shrink-0" />
                        <span className="text-slate-800 dark:text-slate-200">{feat}</span>
                      </div>
                      <button
                        type="button"
                        onClick={() => handleRemoveFeature(idx)}
                        className="text-slate-400 hover:text-rose-500 p-1"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))}
                </div>

                <div className="flex gap-2">
                  <input
                    type="text"
                    placeholder="Add another key feature or engineering benefit..."
                    value={newFeatureText}
                    onChange={(e) => setNewFeatureText(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        e.preventDefault();
                        handleAddFeature();
                      }
                    }}
                    className="flex-1 px-3 py-2 text-xs clay-input rounded-xl"
                  />
                  <button
                    type="button"
                    onClick={handleAddFeature}
                    className="clay-btn clay-btn-secondary px-3 py-2 text-xs font-bold flex items-center gap-1"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    Add
                  </button>
                </div>
              </div>

              {/* Technical Specifications */}
              <div className="space-y-3 pt-4 border-t border-slate-100 dark:border-slate-800">
                <label className="text-xs font-black uppercase tracking-wider text-slate-400">
                  4. Technical Specifications Table
                </label>

                <div className="space-y-1.5">
                  {specList.map((spec, idx) => (
                    <div key={idx} className="flex items-center justify-between gap-3 p-2 rounded-xl bg-slate-50 dark:bg-slate-900/40 border border-slate-200/60 dark:border-slate-800 text-xs">
                      <div className="flex items-center gap-3">
                        <span className="font-bold text-slate-500 w-28 truncate">{spec.key}:</span>
                        <span className="font-semibold text-slate-800 dark:text-slate-200">{spec.value}</span>
                      </div>
                      <button
                        type="button"
                        onClick={() => handleRemoveSpec(idx)}
                        className="text-slate-400 hover:text-rose-500 p-1"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))}
                </div>

                <div className="grid grid-cols-5 gap-2">
                  <input
                    type="text"
                    placeholder="Parameter (e.g. Weight)"
                    value={specKey}
                    onChange={(e) => setSpecKey(e.target.value)}
                    className="col-span-2 px-3 py-2 text-xs clay-input rounded-xl"
                  />
                  <input
                    type="text"
                    placeholder="Value (e.g. 1.35 kg)"
                    value={specVal}
                    onChange={(e) => setSpecVal(e.target.value)}
                    className="col-span-2 px-3 py-2 text-xs clay-input rounded-xl"
                  />
                  <button
                    type="button"
                    onClick={handleAddSpec}
                    className="clay-btn clay-btn-secondary py-2 text-xs font-bold flex items-center justify-center gap-1"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    Add
                  </button>
                </div>
              </div>

              {/* Shipping & Delivery Options */}
              <div className="space-y-3 pt-4 border-t border-slate-100 dark:border-slate-800">
                <label className="text-xs font-black uppercase tracking-wider text-slate-400">
                  5. Logistics & Shipping
                </label>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div className="flex items-center justify-between p-3 rounded-xl bg-slate-50 dark:bg-slate-900/40 border border-slate-200/60 dark:border-slate-800">
                    <div>
                      <span className="text-xs font-bold text-slate-800 dark:text-slate-200">Free Shipping</span>
                      <p className="text-[10px] text-slate-400">Complimentary delivery</p>
                    </div>
                    <input
                      type="checkbox"
                      checked={freeShipping}
                      onChange={(e) => setFreeShipping(e.target.checked)}
                      className="w-4 h-4 accent-amber-500 rounded cursor-pointer"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-slate-500 mb-1">Delivery Time</label>
                    <input
                      type="text"
                      value={shippingTime}
                      onChange={(e) => setShippingTime(e.target.value)}
                      className="w-full px-3 py-2 text-xs clay-input rounded-xl"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-slate-500 mb-1">Ships From</label>
                    <input
                      type="text"
                      value={shipsFrom}
                      onChange={(e) => setShipsFrom(e.target.value)}
                      className="w-full px-3 py-2 text-xs clay-input rounded-xl"
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* Right 1 Col: Live Product Card Preview */}
            <div className="space-y-4">
              <label className="text-xs font-black uppercase tracking-wider text-slate-400">
                Live Store Card Preview
              </label>

              <div className="clay-card rounded-3xl overflow-hidden bg-white dark:bg-[#181D2E] border border-slate-200 dark:border-slate-800 shadow-xl transition-all">
                <div className="relative aspect-video bg-slate-900 overflow-hidden">
                  <img
                    src={previewImage}
                    alt={title || 'Product'}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute top-2.5 left-2.5 flex items-center gap-1.5">
                    <span className="px-2 py-0.5 rounded-full bg-amber-500 text-white font-black text-[9px] uppercase tracking-wider shadow-sm">
                      {condition === 'new' ? 'Brand New' : condition}
                    </span>
                    {numCompare > numPrice && numPrice > 0 && (
                      <span className="px-2 py-0.5 rounded-full bg-rose-500 text-white font-black text-[9px]">
                        Save {Math.round(((numCompare - numPrice) / numCompare) * 100)}%
                      </span>
                    )}
                  </div>
                </div>

                <div className="p-4 space-y-3">
                  <div className="text-[10px] font-extrabold uppercase text-amber-600 dark:text-amber-400">
                    {brand || 'Brand'}
                  </div>
                  <h3 className="text-sm font-extrabold text-slate-900 dark:text-slate-100 line-clamp-2">
                    {title || 'Your Product Title Goes Here'}
                  </h3>

                  <div className="flex items-baseline gap-2">
                    <span className="text-lg font-black text-slate-900 dark:text-slate-100">
                      ${numPrice > 0 ? numPrice.toFixed(2) : '89.00'}
                    </span>
                    {numCompare > numPrice && (
                      <span className="text-xs text-slate-400 line-through">
                        ${numCompare.toFixed(2)}
                      </span>
                    )}
                    <span className="text-[11px] text-slate-400 font-medium ml-auto">
                      ≈ {(numPrice * 3.75).toFixed(0)} SAR
                    </span>
                  </div>

                  <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-900/60 border border-slate-200/60 dark:border-slate-800 text-[10px] text-slate-500 dark:text-slate-400 space-y-1">
                    <p className="flex items-center gap-1 text-emerald-600 dark:text-emerald-400 font-bold">
                      <Truck className="w-3 h-3" />
                      <span>{freeShipping ? 'Free Express Delivery' : 'Standard Shipping'}</span>
                    </p>
                    <p>Dispatch: {shippingTime}</p>
                    <p>Stock: {stock} units available</p>
                  </div>

                  <div className="pt-2 flex items-center gap-2 border-t border-slate-100 dark:border-slate-800 text-xs">
                    <img
                      src={currentUser?.avatar || '/assets/aistudio/Screenshot_20240115_120152_DWG_FastView_e3b92bfb.jpg'}
                      alt="Seller"
                      className="w-6 h-6 rounded-full object-cover"
                    />
                    <span className="font-bold text-slate-700 dark:text-slate-300 truncate">
                      {currentUser?.displayName || currentUser?.name || 'Verified Seller'}
                    </span>
                    <ShieldCheck className="w-3.5 h-3.5 text-violet-500 ml-auto flex-shrink-0" />
                  </div>
                </div>
              </div>

              <div className="p-3.5 rounded-2xl bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-900/50 text-[11px] text-amber-800 dark:text-amber-300 leading-relaxed">
                ⚖️ <strong>Seller Agreement:</strong> All listed equipment, tools, and digital files must conform to the <em>World Video Hub Commercial Standards</em>. In-stock items must be dispatched within 48 hours.
              </div>
            </div>
          </div>

          {/* Action Footer */}
          <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-100 dark:border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="clay-btn clay-btn-secondary px-5 py-2.5 text-xs font-bold"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="clay-btn clay-btn-primary px-6 py-2.5 text-xs font-black bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-white shadow-lg shadow-amber-500/25"
            >
              {isSubmitting ? 'Publishing Listing...' : 'Publish Product Listing'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
