import React from 'react';
import { useApp } from '../../context/AppContext.tsx';
import {
  Home,
  Flame,
  Compass,
  Users,
  UploadCloud,
  Briefcase,
  MessageSquare,
  Bell,
  Sparkles,
  User,
  ShieldAlert,
  BookmarkCheck,
  Building2,
  FileCheck2,
  ListVideo,
  X,
  Zap,
  ShieldCheck,
  Coins,
  ShoppingBag,
  Heart
} from 'lucide-react';

export const Sidebar: React.FC<{ isOpen: boolean; onCloseMobile?: () => void }> = ({ isOpen, onCloseMobile }) => {
  const { activeView, setActiveView, currentUser, unreadCount, playlists, addVideoToPlaylist, showToast, deletePlaylist } = useApp();

  const handleNav = (view: any) => {
    setActiveView(view);
    if (onCloseMobile) onCloseMobile();
  };

  const mainNav = [
    { id: 'home', label: 'Home', icon: Home, color: 'text-violet-500' },
    { id: 'store', label: 'Online Store', icon: ShoppingBag, color: 'text-amber-500', isStore: true },
    { id: 'live_match', label: 'Live Match (Win Gifts)', icon: Zap, color: 'text-rose-500', live: true },
    { id: 'shorts', label: 'Shorts', icon: Flame, color: 'text-rose-500' },
    { id: 'explore', label: 'Explore & Tech', icon: Compass, color: 'text-blue-500' },
    { id: 'playlists', label: 'Playlists & Library', icon: ListVideo, color: 'text-indigo-500', badge: playlists.length },
    { id: 'subscriptions', label: 'Subscriptions', icon: Sparkles, color: 'text-amber-500' },
  ];

  const jobsNav = [
    { id: 'jobs', label: 'Global Jobs', icon: Briefcase, color: 'text-emerald-500' },
    { id: 'applications', label: currentUser?.role === 'employer' ? 'Applications Review' : 'My Applications', icon: FileCheck2, color: 'text-teal-500' },
    { id: 'saved_jobs', label: 'Saved Vacancies', icon: BookmarkCheck, color: 'text-indigo-500' },
  ];

  const socialNav = [
    { id: 'messages', label: 'Messages', icon: MessageSquare, color: 'text-sky-500' },
    { id: 'notifications', label: 'Notifications', icon: Bell, badge: unreadCount, color: 'text-purple-500' },
    { id: 'profile', label: 'Creator Channel', icon: User, color: 'text-pink-500' },
  ];

  return (
    <aside
      className={`fixed lg:sticky top-[57px] left-0 z-30 h-[calc(100vh-57px)] overflow-y-auto no-scrollbar transition-all duration-300 ease-in-out bg-white/90 dark:bg-[#131722]/95 backdrop-blur-md border-r border-slate-200/60 dark:border-slate-800/80 ${
        isOpen ? 'w-64 px-3 py-4' : 'w-0 lg:w-20 px-0 lg:px-2 py-4'
      }`}
    >
      <div className={`space-y-6 ${!isOpen ? 'hidden lg:block' : ''}`}>
        {/* Main Section */}
        <div>
          {isOpen && <div className="px-3 pb-2 text-[10px] font-extrabold uppercase tracking-wider text-slate-400 dark:text-slate-500">Discover</div>}
          <div className="space-y-1">
            {mainNav.map((item) => {
              const Icon = item.icon;
              const isActive = activeView === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => handleNav(item.id)}
                  title={item.label}
                  className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-2xl font-bold text-xs transition-all active:scale-95 ${
                    isActive
                      ? 'bg-violet-600 text-white shadow-md shadow-violet-500/25'
                      : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800/60'
                  } ${!isOpen ? 'justify-center' : ''}`}
                >
                  <Icon className={`w-5 h-5 flex-shrink-0 ${isActive ? 'text-white' : item.color}`} />
                  {isOpen && (
                    <div className="flex items-center justify-between flex-1 min-w-0">
                      <span className="truncate">{item.label}</span>
                      {item.live && (
                        <span className="px-1.5 py-0.5 rounded-full bg-rose-500 text-white text-[9px] font-black uppercase tracking-wider animate-pulse flex-shrink-0">
                          LIVE
                        </span>
                      )}
                      {(item as any).isStore && (
                        <span className="px-1.5 py-0.5 rounded-full bg-amber-500 text-white text-[9px] font-black uppercase tracking-wider flex-shrink-0 shadow-sm">
                          SHOP
                        </span>
                      )}
                    </div>
                  )}
                </button>
              );
            })}
          </div>
        </div>

        {/* Global Jobs Portal Section */}
        <div>
          {isOpen && <div className="px-3 pb-2 text-[10px] font-extrabold uppercase tracking-wider text-emerald-600 dark:text-emerald-400">Careers & Façade</div>}
          <div className="space-y-1">
            {jobsNav.map((item) => {
              const Icon = item.icon;
              const isActive = activeView === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => handleNav(item.id === 'saved_jobs' ? 'jobs' : item.id)}
                  title={item.label}
                  className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-2xl font-bold text-xs transition-all active:scale-95 ${
                    isActive
                      ? 'bg-emerald-600 text-white shadow-md shadow-emerald-500/25'
                      : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800/60'
                  } ${!isOpen ? 'justify-center' : ''}`}
                >
                  <Icon className={`w-5 h-5 flex-shrink-0 ${isActive ? 'text-white' : item.color}`} />
                  {isOpen && <span className="truncate">{item.label}</span>}
                </button>
              );
            })}
          </div>
        </div>

        {/* Social & Network */}
        <div>
          {isOpen && <div className="px-3 pb-2 text-[10px] font-extrabold uppercase tracking-wider text-slate-400 dark:text-slate-500">Social</div>}
          <div className="space-y-1">
            {socialNav.map((item) => {
              const Icon = item.icon;
              const isActive = activeView === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => handleNav(item.id)}
                  title={item.label}
                  className={`w-full flex items-center justify-between px-3 py-2.5 rounded-2xl font-bold text-xs transition-all active:scale-95 ${
                    isActive
                      ? 'bg-violet-600 text-white shadow-md shadow-violet-500/25'
                      : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800/60'
                  } ${!isOpen ? 'justify-center' : ''}`}
                >
                  <div className="flex items-center gap-3 truncate">
                    <Icon className={`w-5 h-5 flex-shrink-0 ${isActive ? 'text-white' : item.color}`} />
                    {isOpen && <span className="truncate">{item.label}</span>}
                  </div>
                  {isOpen && item.badge !== undefined && item.badge > 0 && (
                    <span className="px-1.5 py-0.5 rounded-full text-[10px] font-bold bg-rose-500 text-white">
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        </div>

        {/* Playlists */}
        <div>
          {isOpen && <div className="px-3 pb-2 text-[10px] font-extrabold uppercase tracking-wider text-slate-400 dark:text-slate-500">Playlists</div>}
          <div className="space-y-1">
            {playlists.map((playlist) => (
              <div
                key={playlist.id}
                onDragOver={(e) => e.preventDefault()}
                onDrop={(e) => {
                  const videoId = e.dataTransfer.getData('videoId');
                  if (videoId) {
                    addVideoToPlaylist(playlist.id, videoId);
                    showToast(`Added to ${playlist.name}`);
                  }
                }}
                className={`w-full flex items-center justify-between gap-2 px-3 py-2 rounded-2xl font-bold text-xs text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800/60 group transition-all ${!isOpen ? 'justify-center' : ''}`}
              >
                <button
                  type="button"
                  onClick={() => handleNav('playlists')}
                  title={playlist.name}
                  className="flex items-center gap-3 truncate flex-1 text-left active:scale-95 transition-transform"
                >
                  <BookmarkCheck className="w-5 h-5 text-indigo-500 flex-shrink-0" />
                  {isOpen && <span className="truncate">{playlist.name}</span>}
                </button>
                {isOpen && (
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      deletePlaylist(playlist.id);
                    }}
                    title={`Delete ${playlist.name}`}
                    className="text-slate-400 hover:text-rose-500 transition p-1 rounded-lg hover:bg-rose-50 dark:hover:bg-rose-950/40"
                  >
                    <X className="w-4 h-4" />
                  </button>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Creator Studio & Admin */}
        <div>
          {isOpen && <div className="px-3 pb-2 text-[10px] font-extrabold uppercase tracking-wider text-slate-400 dark:text-slate-500">Workspace</div>}
          <div className="space-y-1">
            <button
              onClick={() => handleNav('upload')}
              title="Creator Upload Studio"
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-2xl font-bold text-xs transition-all active:scale-95 ${
                activeView === 'upload'
                  ? 'bg-orange-600 text-white shadow-md shadow-orange-500/25'
                  : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800/60'
              } ${!isOpen ? 'justify-center' : ''}`}
            >
              <UploadCloud className="w-5 h-5 text-orange-500" />
              {isOpen && <span>Upload Studio</span>}
            </button>

            {/* Creator Monetization & Partner Program */}
            <button
              onClick={() => handleNav('monetization')}
              title="Creator Monetization & Partner Program"
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-2xl font-bold text-xs transition-all active:scale-95 ${
                activeView === 'monetization'
                  ? 'bg-amber-600 text-white shadow-md shadow-amber-500/25'
                  : 'text-amber-600 dark:text-amber-400 hover:bg-amber-50 dark:hover:bg-amber-950/30'
              } ${!isOpen ? 'justify-center' : ''}`}
            >
              <Coins className="w-5 h-5 text-amber-500" />
              {isOpen && (
                <div className="flex items-center justify-between w-full">
                  <span>Monetization</span>
                  <span className="text-[9px] px-1.5 py-0.5 rounded bg-amber-100 dark:bg-amber-900/60 text-amber-800 dark:text-amber-200 font-extrabold">
                    PARTNER
                  </span>
                </div>
              )}
            </button>

            {/* Admin console button */}
            <button
              onClick={() => handleNav('admin')}
              title="Administrator Dashboard"
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-2xl font-bold text-xs transition-all active:scale-95 ${
                activeView === 'admin'
                  ? 'bg-rose-600 text-white shadow-md shadow-rose-500/25'
                  : 'text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/30'
              } ${!isOpen ? 'justify-center' : ''}`}
            >
              <ShieldAlert className="w-5 h-5" />
              {isOpen && (
                <div className="flex items-center justify-between w-full">
                  <span>Admin Panel</span>
                  <span className="text-[9px] px-1.5 py-0.5 rounded bg-rose-200 dark:bg-rose-900/60 text-rose-800 dark:text-rose-200">
                    SECURE
                  </span>
                </div>
              )}
            </button>
            {/* Platform Rules & Legal button */}
            <button
              onClick={() => handleNav('policies')}
              title="World Video Hub Supplementary Platform Rules"
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-2xl font-bold text-xs transition-all active:scale-95 ${
                activeView === 'policies'
                  ? 'bg-indigo-600 text-white shadow-md shadow-indigo-500/25'
                  : 'text-indigo-600 dark:text-indigo-400 hover:bg-indigo-50 dark:hover:bg-indigo-950/30'
              } ${!isOpen ? 'justify-center' : ''}`}
            >
              <ShieldCheck className="w-5 h-5" />
              {isOpen && (
                <div className="flex items-center justify-between w-full">
                  <span>Platform Rules (A-H)</span>
                  <span className="text-[9px] px-1.5 py-0.5 rounded bg-indigo-100 dark:bg-indigo-900/60 text-indigo-700 dark:text-indigo-200 font-bold">
                    LEGAL
                  </span>
                </div>
              )}
            </button>
          </div>
        </div>

        {/* Claymorphic Pro Badge Callout */}
        {isOpen && (
          <div className="clay-card p-3.5 bg-gradient-to-br from-violet-500/10 via-purple-500/5 to-pink-500/10 border border-violet-200/50 dark:border-violet-800/50">
            <div className="flex items-center gap-2 mb-1.5">
              <Sparkles className="w-4 h-4 text-violet-600 dark:text-violet-400" />
              <span className="text-xs font-bold text-slate-800 dark:text-slate-100">Pro Creator & Jobs</span>
            </div>
            <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-relaxed mb-2.5">
              Upgrade for unlimited job applications, 4K video uploads, and verified badge eligibility.
            </p>
            <button
              onClick={() => handleNav('subscriptions')}
              className="w-full py-1.5 text-[11px] font-bold text-violet-700 dark:text-violet-300 bg-violet-100 dark:bg-violet-900/40 rounded-xl hover:bg-violet-200 transition text-center"
            >
              View Membership Plans
            </button>
          </div>
        )}
      </div>
    </aside>
  );
};
