import React, { useRef, useState, useEffect } from 'react';
import {
  Sparkles,
  Cpu,
  GraduationCap,
  Gamepad2,
  Palette,
  Building2,
  Layers,
  HardHat,
  Wrench,
  ChevronLeft,
  ChevronRight,
  X,
  Filter
} from 'lucide-react';

export interface CategoryTopic {
  id: string;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
  accentColor: string;
  badge?: string;
  description: string;
}

export const CATEGORY_TOPICS: CategoryTopic[] = [
  {
    id: 'All',
    label: 'All Topics',
    icon: Sparkles,
    accentColor: 'from-violet-500 to-indigo-500',
    description: 'Explore all engineering, architecture, and technology videos'
  },
  {
    id: 'Technology',
    label: 'Technology',
    icon: Cpu,
    accentColor: 'from-blue-500 to-cyan-500',
    badge: 'Trending',
    description: 'AI, Generative Structural Optimization, Creator Tech & Hardware'
  },
  {
    id: 'Education',
    label: 'Education',
    icon: GraduationCap,
    accentColor: 'from-emerald-500 to-teal-500',
    badge: 'Masterclass',
    description: 'Curtain Wall Courses, Seismic Analysis & Professional Academies'
  },
  {
    id: 'Gaming',
    label: 'Gaming',
    icon: Gamepad2,
    accentColor: 'from-purple-500 to-pink-500',
    badge: 'Interactive',
    description: 'Unreal Engine 5 Physics, Construction Simulators & Match Battles'
  },
  {
    id: 'Design',
    label: 'Design',
    icon: Palette,
    accentColor: 'from-rose-500 to-amber-500',
    description: 'Parametric Rhino Grasshopper, Façade Aesthetics & UI Systems'
  },
  {
    id: 'Engineering',
    label: 'Engineering',
    icon: Building2,
    accentColor: 'from-amber-500 to-orange-500',
    description: 'Aluminium Extrusions, Unitized Envelopes & Glass Testing'
  },
  {
    id: 'BIM & CAD',
    label: 'BIM & CAD',
    icon: Layers,
    accentColor: 'from-indigo-500 to-violet-500',
    description: 'Revit 2026 Families, AutoCAD Detailing & IFC Coordination'
  },
  {
    id: 'Construction',
    label: 'Construction',
    icon: HardHat,
    accentColor: 'from-yellow-500 to-amber-600',
    description: 'Tower Crane Rigging, Site Safety & High-Rise Glazing'
  },
  {
    id: 'Fabrication',
    label: 'Fabrication',
    icon: Wrench,
    accentColor: 'from-slate-600 to-slate-800',
    description: '5-Axis CNC Milling, Extrusion Dies & Factory Production'
  }
];

interface CategoryFilterBarProps {
  selectedCategory: string;
  onSelectCategory: (category: string) => void;
  videoCount?: number;
  className?: string;
}

export const CategoryFilterBar: React.FC<CategoryFilterBarProps> = ({
  selectedCategory,
  onSelectCategory,
  videoCount,
  className = ''
}) => {
  const scrollRef = useRef<HTMLDivElement>(null);
  const [canScrollLeft, setCanScrollLeft] = useState(false);
  const [canScrollRight, setCanScrollRight] = useState(true);

  const checkScroll = () => {
    if (!scrollRef.current) return;
    const { scrollLeft, scrollWidth, clientWidth } = scrollRef.current;
    setCanScrollLeft(scrollLeft > 10);
    setCanScrollRight(scrollLeft + clientWidth < scrollWidth - 10);
  };

  useEffect(() => {
    checkScroll();
    window.addEventListener('resize', checkScroll);
    return () => window.removeEventListener('resize', checkScroll);
  }, []);

  const scroll = (direction: 'left' | 'right') => {
    if (!scrollRef.current) return;
    const amount = direction === 'left' ? -260 : 260;
    scrollRef.current.scrollBy({ left: amount, behavior: 'smooth' });
    setTimeout(checkScroll, 300);
  };

  const activeTopic = CATEGORY_TOPICS.find(t => t.id === selectedCategory) || CATEGORY_TOPICS[0];

  return (
    <div className={`space-y-2.5 ${className}`}>
      {/* Category Filter Pills Container */}
      <div className="relative group/bar flex items-center">
        {/* Left Scroll Arrow */}
        {canScrollLeft && (
          <button
            type="button"
            onClick={() => scroll('left')}
            className="absolute left-0 z-20 p-2 rounded-2xl bg-white/95 dark:bg-[#181D2E]/95 shadow-lg border border-slate-200/80 dark:border-slate-800 text-slate-700 dark:text-slate-200 hover:text-violet-600 hover:scale-105 active:scale-95 transition-all backdrop-blur-md"
            aria-label="Scroll topics left"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>
        )}

        {/* Horizontal Chips Carousel */}
        <div
          ref={scrollRef}
          onScroll={checkScroll}
          className="flex items-center gap-2 md:gap-2.5 overflow-x-auto no-scrollbar py-1 px-1 scroll-smooth w-full"
        >
          {CATEGORY_TOPICS.map((topic) => {
            const isSelected = selectedCategory === topic.id || (selectedCategory === 'All' && topic.id === 'All');
            const Icon = topic.icon;

            return (
              <button
                key={topic.id}
                type="button"
                onClick={() => onSelectCategory(topic.id)}
                className={`relative flex items-center gap-2 px-4 py-2 rounded-2xl text-xs font-black whitespace-nowrap transition-all duration-200 active:scale-95 cursor-pointer ${
                  isSelected
                    ? 'clay-btn clay-btn-primary shadow-md shadow-violet-500/25 ring-2 ring-violet-500/40 text-white'
                    : 'clay-card bg-white/90 dark:bg-[#181D2E]/90 text-slate-700 dark:text-slate-300 hover:text-violet-600 dark:hover:text-violet-400 hover:border-violet-300 dark:hover:border-violet-700 border border-slate-200/80 dark:border-slate-800 shadow-sm'
                }`}
              >
                <Icon
                  className={`w-4 h-4 transition-transform duration-200 ${
                    isSelected ? 'scale-110 text-white' : 'text-slate-400 group-hover:text-violet-500'
                  }`}
                />
                <span>{topic.label}</span>

                {/* Optional mini badge (e.g. Trending, Masterclass, Interactive) */}
                {topic.badge && !isSelected && (
                  <span className="hidden sm:inline-block px-1.5 py-0.5 rounded-md text-[9px] font-black uppercase tracking-wider bg-violet-100 dark:bg-violet-950/80 text-violet-700 dark:text-violet-300">
                    {topic.badge}
                  </span>
                )}
              </button>
            );
          })}
        </div>

        {/* Right Scroll Arrow */}
        {canScrollRight && (
          <button
            type="button"
            onClick={() => scroll('right')}
            className="absolute right-0 z-20 p-2 rounded-2xl bg-white/95 dark:bg-[#181D2E]/95 shadow-lg border border-slate-200/80 dark:border-slate-800 text-slate-700 dark:text-slate-200 hover:text-violet-600 hover:scale-105 active:scale-95 transition-all backdrop-blur-md"
            aria-label="Scroll topics right"
          >
            <ChevronRight className="w-4 h-4" />
          </button>
        )}
      </div>

      {/* Active Filter Status & Reset Strip (When filtering by specific topic) */}
      {selectedCategory !== 'All' && (
        <div className="flex items-center justify-between gap-3 px-3.5 py-2 rounded-2xl bg-violet-50/80 dark:bg-violet-950/30 border border-violet-200/60 dark:border-violet-900/40 text-xs animate-in fade-in slide-in-from-top-1 duration-200">
          <div className="flex items-center gap-2 truncate">
            <span className="flex items-center gap-1 font-bold text-violet-700 dark:text-violet-300">
              <Filter className="w-3.5 h-3.5 text-violet-500 flex-shrink-0" />
              <span>Filtering by:</span>
            </span>
            <span className="font-black text-slate-900 dark:text-slate-100 px-2 py-0.5 rounded-lg bg-white dark:bg-slate-800 border border-violet-200 dark:border-violet-800/60 shadow-xs">
              {activeTopic.label}
            </span>
            <span className="hidden md:inline-block text-[11px] text-slate-500 dark:text-slate-400 truncate">
              — {activeTopic.description}
            </span>
          </div>

          <div className="flex items-center gap-2 flex-shrink-0">
            {videoCount !== undefined && (
              <span className="text-[11px] font-bold text-slate-500 dark:text-slate-400">
                {videoCount} {videoCount === 1 ? 'video' : 'videos'} found
              </span>
            )}
            <button
              type="button"
              onClick={() => onSelectCategory('All')}
              className="flex items-center gap-1 px-2.5 py-1 rounded-xl bg-white dark:bg-slate-800 hover:bg-rose-50 dark:hover:bg-rose-950/40 text-slate-600 dark:text-slate-300 hover:text-rose-600 dark:hover:text-rose-400 font-bold text-xs border border-slate-200 dark:border-slate-700 transition"
            >
              <X className="w-3 h-3" />
              <span>Reset to All</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
