import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext.tsx';
import { Conversation, Message } from '../../types/index.ts';
import {
  MessageSquare,
  Send,
  User,
  Shield,
  Briefcase,
  Search,
  CheckCheck
} from 'lucide-react';

export const MessagesView: React.FC = () => {
  const { currentUser, showToast } = useApp();
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [activeConv, setActiveConv] = useState<Conversation | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputText, setInputText] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchConversations();
  }, []);

  const fetchConversations = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/messages/conversations');
      if (res.ok) {
        const data = await res.json();
        setConversations(data.conversations || []);
        if (data.conversations?.length > 0) {
          setActiveConv(data.conversations[0]);
          fetchMessages(data.conversations[0].id);
        }
      }
    } catch (e) {
      console.warn('Error loading conversations', e);
    } finally {
      setLoading(false);
    }
  };

  const fetchMessages = async (convId: string) => {
    try {
      const res = await fetch(`/api/messages/${convId}`);
      if (res.ok) {
        const data = await res.json();
        setMessages(data.messages || []);
      }
    } catch (e) {
      console.warn('Error loading messages', e);
    }
  };

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim() || !activeConv) return;

    try {
      const res = await fetch('/api/messages', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          conversationId: activeConv.id,
          text: inputText.trim()
        })
      });

      if (res.ok) {
        const data = await res.json();
        setMessages(prev => [...prev, data.message]);
        setInputText('');
      }
    } catch (e) {
      showToast('Could not send message', 'error');
    }
  };

  return (
    <div className="max-w-6xl mx-auto space-y-6 pb-16">
      <div className="clay-card p-6 bg-gradient-to-r from-blue-500/10 via-sky-500/10 to-indigo-500/10 border border-blue-300/40 dark:border-blue-700/40">
        <div className="flex items-center gap-2 text-blue-600 dark:text-blue-400 font-extrabold text-xs uppercase tracking-wider">
          <MessageSquare className="w-4 h-4" />
          Direct Messaging & Recruiter Communications
        </div>
        <h1 className="text-2xl font-black text-slate-900 dark:text-slate-100 tracking-tight mt-1">
          Candidate & Creator Chats
        </h1>
        <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
          Coordinate technical interviews, negotiate offers, and discuss façade engineering projects in a private environment.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-12 gap-5 h-[620px]">
        {/* Left: Conversations List (4 cols) */}
        <div className="md:col-span-4 clay-card p-3 bg-white dark:bg-[#181D2E] flex flex-col overflow-hidden">
          <div className="p-2 border-b border-slate-100 dark:border-slate-800">
            <h3 className="text-xs font-black uppercase text-slate-400">Conversations</h3>
          </div>

          <div className="flex-1 overflow-y-auto no-scrollbar py-2 space-y-1.5">
            {conversations.map((c) => {
              const other = c.participants.find(p => p.id !== currentUser?.id) || c.participants[0];
              const isSelected = activeConv?.id === c.id;

              return (
                <div
                  key={c.id}
                  onClick={() => {
                    setActiveConv(c);
                    fetchMessages(c.id);
                  }}
                  className={`p-2.5 rounded-2xl cursor-pointer flex items-center gap-3 transition ${
                    isSelected
                      ? 'bg-violet-50 dark:bg-violet-950/40 border border-violet-200 dark:border-violet-800'
                      : 'hover:bg-slate-50 dark:hover:bg-slate-800/40'
                  }`}
                >
                  <img
                    src={other.avatar}
                    alt={other.name}
                    className="w-10 h-10 rounded-full object-cover border border-slate-200 dark:border-slate-700"
                  />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between">
                      <h4 className="text-xs font-bold text-slate-900 dark:text-slate-100 truncate">
                        {other.name}
                      </h4>
                    </div>
                    <p className="text-[11px] text-slate-500 dark:text-slate-400 truncate mt-0.5">
                      {c.lastMessage || 'Start conversation...'}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right: Message Thread (8 cols) */}
        <div className="md:col-span-8 clay-card p-4 bg-white dark:bg-[#181D2E] flex flex-col justify-between overflow-hidden">
          {activeConv ? (
            <>
              {/* Thread Header */}
              <div className="pb-3 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <img
                    src={
                      activeConv.participants.find(p => p.id !== currentUser?.id)?.avatar ||
                      activeConv.participants[0].avatar
                    }
                    alt="Chat"
                    className="w-9 h-9 rounded-full object-cover"
                  />
                  <div>
                    <h3 className="text-xs font-bold text-slate-900 dark:text-slate-100">
                      {activeConv.participants.find(p => p.id !== currentUser?.id)?.name || 'Direct Chat'}
                    </h3>
                    <span className="text-[10px] text-emerald-500 font-bold flex items-center gap-1">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                      Active Candidate / Employer
                    </span>
                  </div>
                </div>
              </div>

              {/* Messages Body */}
              <div className="flex-1 overflow-y-auto no-scrollbar py-4 space-y-3">
                {messages.map((m) => {
                  const isMine = m.senderId === currentUser?.id;
                  return (
                    <div
                      key={m.id}
                      className={`flex gap-2.5 max-w-[80%] ${isMine ? 'ml-auto flex-row-reverse' : ''}`}
                    >
                      <img
                        src={m.senderAvatar}
                        alt={m.senderName}
                        className="w-7 h-7 rounded-full object-cover flex-shrink-0 mt-0.5"
                      />
                      <div
                        className={`p-3 rounded-2xl text-xs leading-relaxed ${
                          isMine
                            ? 'bg-violet-600 text-white rounded-br-none shadow-sm'
                            : 'bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-slate-200 rounded-bl-none'
                        }`}
                      >
                        <p>{m.text}</p>
                        <span className={`text-[9px] block text-right mt-1 opacity-70`}>
                          {new Date(m.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Input Form */}
              <form onSubmit={handleSendMessage} className="pt-3 border-t border-slate-100 dark:border-slate-800 flex gap-2">
                <input
                  type="text"
                  value={inputText}
                  onChange={(e) => setInputText(e.target.value)}
                  placeholder="Type a message or candidate response..."
                  className="flex-1 px-4 py-2 text-xs clay-input"
                />
                <button
                  type="submit"
                  disabled={!inputText.trim()}
                  className="clay-btn clay-btn-primary px-4 py-2 text-xs font-bold gap-1 disabled:opacity-40"
                >
                  <Send className="w-3.5 h-3.5" />
                  Send
                </button>
              </form>
            </>
          ) : (
            <div className="flex-1 flex items-center justify-center text-xs text-slate-400">
              Select a conversation to start messaging.
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
