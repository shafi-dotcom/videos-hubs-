import { useState, useEffect } from 'react';

const DEFAULT_RECENT_SEARCHES = [
  'Curtain Wall Glazing',
  '4K Creator Camera',
  'Revit BIM Families',
  'ANC Studio Headphones',
  'Titanium Smartwatch'
];

export const useSearchHistory = (storageKey = 'searchHistory') => {
  const [history, setHistory] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem(storageKey);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) {
          return parsed.slice(0, 5);
        }
      }
      return DEFAULT_RECENT_SEARCHES;
    } catch {
      return DEFAULT_RECENT_SEARCHES;
    }
  });

  useEffect(() => {
    try {
      const saved = localStorage.getItem(storageKey);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) {
          setHistory(parsed.slice(0, 5));
        }
      }
    } catch {
      // fallback
    }
  }, [storageKey]);

  const addQuery = (query: string) => {
    const trimmed = query.trim();
    if (!trimmed) return;
    setHistory(prev => {
      const newHistory = [trimmed, ...prev.filter(item => item.toLowerCase() !== trimmed.toLowerCase())].slice(0, 5);
      try {
        localStorage.setItem(storageKey, JSON.stringify(newHistory));
      } catch {
        // ignore
      }
      return newHistory;
    });
  };

  const removeQuery = (queryToRemove: string) => {
    setHistory(prev => {
      const newHistory = prev.filter(item => item !== queryToRemove);
      try {
        localStorage.setItem(storageKey, JSON.stringify(newHistory));
      } catch {
        // ignore
      }
      return newHistory;
    });
  };

  const clearHistory = () => {
    setHistory([]);
    try {
      localStorage.removeItem(storageKey);
    } catch {
      // ignore
    }
  };

  return { history, addQuery, removeQuery, clearHistory };
};

